import Flutter
import UIKit
import Banked

private let CHANNEL = "com.example.banked_flutter_sdk_example/banked_sdk"
//private let BANKED_API_KEY = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
private let apiKey = "15eb11471a6ae61174833a72b6b963e9"
private let continueURL = "https://checkoutdemo.page.link/banked"

public class SwiftBankedPlugin: NSObject, FlutterPlugin {
    
    public static func register(with registrar: FlutterPluginRegistrar) {
        let channel = FlutterMethodChannel(name: "banked_plugin", binaryMessenger: registrar.messenger())
        let instance = SwiftBankedPlugin()
        registrar.addMethodCallDelegate(instance, channel: channel)
    }

    public func handle(_ call: FlutterMethodCall, result: @escaping FlutterResult) {
        test()
        result("iOS " + UIDevice.current.systemVersion)
    }
    
    func test() {
        
        guard let vc = UIApplication.shared.keyWindow?.rootViewController else {
            return
        }
    
        // test
//        let alertController = UIAlertController(title: "test", message: "message2", preferredStyle: .alert)
//        let action = UIAlertAction(title: "Cancel", style: .cancel)
//        alertController.addAction(action)
//        vc.present(alertController, animated: true)

        BankedCheckout.shared.setUp(apiKey)
        
        BankedCheckout.shared.presentCheckout(vc, paymentId: "231312312312", action: .pay, continueURL: continueURL) { (response) in
            switch response {
            case .success:
                // Handle Success
                print("success")
            case .failure(let error):
                // Handle Error
                print("error \(error)")
            @unknown default:
                fatalError()
            }
        }
    }
    
}
