#import <Flutter/Flutter.h>

@interface BankedPlugin : NSObject<FlutterPlugin>
@end
