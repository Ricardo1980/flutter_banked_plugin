//
//  Generated file. Do not edit.
//

// clang-format off

#import "GeneratedPluginRegistrant.h"

#if __has_include(<banked_plugin/BankedPlugin.h>)
#import <banked_plugin/BankedPlugin.h>
#else
@import banked_plugin;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [BankedPlugin registerWithRegistrar:[registry registrarForPlugin:@"BankedPlugin"]];
}

@end
